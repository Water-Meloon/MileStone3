import React from "react";
import classes from "./ViewTaskDetail.module.css";
function ViewTaskDetail(props) {
  const { task } = props;
  if (!task) {
    return <div className={classes.wrapper}>Loading task details...</div>;
  }
  return (
    <div className={classes.wrapper}>
      <h1>Task Detail</h1>
      <h2>{task.name}</h2>
      <p>Category: {task.category}</p>
      <p>Due Date: {task.dueDate}</p>
      <p>Status: {task.status}</p>
      <p>Location: {task.location}</p>
      <p>Description: {task.description}</p>
      {/* <form action="myToDoList.html">
        <input className={classes.button} type="submit" value="Add to My To Do List" />
      </form> */}
    </div>
  );
}


export default ViewTaskDetail;
