const express = require("express");
const cors = require("cors");
const app = express();
const port = process.env.PORT || 3001;

app.use(express.json());
app.use(cors()); // Add this line to enable CORS

const { MongoClient, ObjectId } = require('mongodb');
const uri = "mongodb+srv://WaterMelon:Cyber2019@milestone3.pv6y8yo.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

client.connect((err) => {
  if (err) throw err;
  console.log("Connected to MongoDB");
});

app.get("/api/Tasks", async (req, res) => {
  const db = client.db("Test");
  const tasksCollection = db.collection("Tasks");
  const tasks = await tasksCollection.find({}).toArray();
  res.json(tasks);
});

app.delete('/api/Tasks/:id', async (req, res) => {
  const taskId = req.params.id;
  console.log('Received taskId:', taskId);
  const db = client.db('Test');
  const tasksCollection = db.collection('Tasks');
  const result = await tasksCollection.deleteOne({ _id: new ObjectId(taskId) });

  if (result.deletedCount === 1) {
    res.status(200).send({ message: 'Task deleted successfully' });
  } else {
    res.status(404).send({ message: 'Task not found' });
  }
});

app.post("/api/Tasks", async (req, res) => {
  const taskData = req.body;
  console.log('Received task data:', taskData);
  const db = client.db("Test");
  const tasksCollection = db.collection("Tasks");

  try {
    const result = await tasksCollection.insertOne(taskData);
    const taskId = result.insertedId;
    console.log('Inserted task with ID:', taskId);

    const createdTask = await tasksCollection.findOne({ _id: taskId });
    console.log('Found created task:', createdTask);

    res.status(201).json(createdTask);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).send({ message: 'Failed to create task' });
  }
});


app.get("/api/Tasks/:id", async (req, res) => {
  const taskId = req.params.id;
  console.log('Received taskId:', taskId);
  const db = client.db("Test");
  const tasksCollection = db.collection("Tasks");
  const task = await tasksCollection.findOne({ _id: new ObjectId(taskId) });

  if (task) {
    res.status(200).json(task);
  } else {
    res.status(404).send({ message: 'Task not found' });
  }
});



app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
