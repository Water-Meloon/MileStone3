import classes from "./Footer.module.css";

const Footer = () => {
  return (
    <div className={classes.wrapper}>
      <div className={classes.footer}>Milestone 2 Group: 9</div>
    </div>
  );
};

export default Footer;
