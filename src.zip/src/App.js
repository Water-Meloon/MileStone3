import { useEffect, useState } from "react";
import classes from "./App.module.css";
import CreateNewTask from "./components/CreateNewTask/CreateNewTask";
import Home from "./components/Home/Home";
import MyToDoList from "./components/MyToDoList/MyToDoList";
import SignUp from "./components/SignUp/SignUp";
import Header from "./components/UI/Header";
import Nav from "./components/UI/Nav";
import ViewTaskDetail from "./components/ViewTaskDetail/ViewTaskDetail";
import Card from "./components/UI/Card";
import Logout from "./components/UI/Logout";
import Footer from "./components/UI/Footer";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import axios from "axios";

function App() {
  const [pageName, setPageName] = useState("Home");
  //   const ctx = useContext(PageContext);

  const [data, setData] = useState();

  useEffect(() => {
    const fetchTasks = async () => {
      const response = await axios.get("http://localhost:3001/api/Tasks");
      setData(response.data);
    };
    fetchTasks();
  }, []);

  const pageChangeHandler = (name) => {
    setPageName(name);
  };

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  useEffect(() => {
    const loginInfo = localStorage.getItem("isLoggedIn");

    if (loginInfo === "1") {
      setIsLoggedIn(true);
    }
  }, []);

  // console.log(ctx.currentPage);
  // console.log(pageName);

  const logoutHandler = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    setUserId(null);
  };

  const [userId, setUserId] = useState(null);
  const loginHandler = (id) => {
    setIsLoggedIn(true);
    setUserId(id);
  };

  const deleteTask = (id) => {
    setData(data.filter((task) => task._id!== id));
  };

  const addTaskHandler = (formData) => {
    setData((prevData) => {
      return [formData, ...prevData];
    });
  };

  const [selectedTask, setSelectedTask] = useState(null);
  const selectTaskHandler = (taskId) => {
  const task = data.find((task) => task._id === taskId);
  setSelectedTask(task);
};

  console.log(localStorage.getItem("isLoggedIn"));
  return (
    <Router>
      <div className={classes.wrapper}>
        <Header pageName={pageName} />
        <Nav changePage={pageChangeHandler} />
        <Card>
          <Routes>
            <Route
              path="/"
              exact
              element={<Home isLoggedIn={isLoggedIn} login={loginHandler} />}
            />
            <Route
              path="/mytodolist"
              element={<MyToDoList tasks={data} deleteHandler={deleteTask} onSelectTask={selectTaskHandler}/>}
            />
            <Route
              path="/createnewtask"
              element={<CreateNewTask addTask={addTaskHandler} userId={userId}/>}
            />
            <Route path="/viewtaskdetail" element={<ViewTaskDetail task={selectedTask}/>} />
            <Route
              path="/signup"
              element={
                <SignUp
                  isLoggedIn={isLoggedIn}
                  login={loginHandler}
                  changePage={pageChangeHandler}
                />
              }
            />
          </Routes>
          {isLoggedIn && <div className={classes.username}>{localStorage.getItem("username")}</div>}
          {isLoggedIn && <Logout logout={logoutHandler} />}
          
        </Card>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
